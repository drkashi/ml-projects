# This is a python script (not built as .exe)
# API is: AppRecommend(...)
# AppRecommend.py is a wraper to get command line arguments as follows:

python.exe  AppRecommend.py  -a 447553564 -e 506627515 504720040 447553564 440045374 512939461 429775439
